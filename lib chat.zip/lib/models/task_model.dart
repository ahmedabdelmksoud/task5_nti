class Task {
  int? id;
  String title;
  bool isDone;
  int userId;

  Task({
    this.id,
    required this.title,
    this.isDone = false,
    required this.userId,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'isDone': isDone ? 1 : 0,
      'userId': userId,
    };
  }

  factory Task.fromMap(Map<String, dynamic> map) {
    return Task(
      id: map['id'],
      title: map['title'],
      isDone: map['isDone'] == 1,
      userId: map['userId'],
    );
  }
}
