import 'package:flutter/material.dart';
import '../database/db_helper.dart';
import '../models/task_model.dart';

class AddEditTaskPage extends StatelessWidget {
  final int userId;
  const AddEditTaskPage({super.key, required this.userId});

  @override
  Widget build(BuildContext context) {
    final controller = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text('Add Task')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: controller,
              decoration: const InputDecoration(labelText: 'Task title'),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  await DBHelper.insertTask(
                    Task(title: controller.text, userId: userId),
                  );
                  Navigator.pop(context);
                },
                child: const Text('Save'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
