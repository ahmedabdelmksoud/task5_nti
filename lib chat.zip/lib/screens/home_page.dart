import 'package:flutter/material.dart';
import '../database/db_helper.dart';
import '../models/task_model.dart';
import '../widgets/task_item.dart';
import 'add_edit_task_page.dart';
import 'profile_page.dart';

class HomePage extends StatefulWidget {
  final int userId;
  const HomePage({super.key, required this.userId});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Task> tasks = [];
  int index = 0;

  @override
  void initState() {
    super.initState();
    loadTasks();
  }

  Future loadTasks() async {
    tasks = await DBHelper.getTasks(widget.userId);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    int done = tasks.where((e) => e.isDone).length;
    int notDone = tasks.length - done;

    final pages = [
      Scaffold(
        appBar: AppBar(title: const Text('My Tasks')),
        floatingActionButton: FloatingActionButton(
          onPressed: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AddEditTaskPage(userId: widget.userId),
              ),
            );
            loadTasks();
          },
          child: const Icon(Icons.add),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Done: $done | Not Done: $notDone',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: tasks.length,
                itemBuilder: (context, i) {
                  return TaskItem(task: tasks[i], onChanged: loadTasks);
                },
              ),
            ),
          ],
        ),
      ),
      ProfilePage(userId: widget.userId),
    ];

    return Scaffold(
      body: pages[index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: index,
        onTap: (i) => setState(() => index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
