import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/user_model.dart';
import '../models/task_model.dart';

class DBHelper {
  static Database? _db;

  static Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await initDB();
    return _db!;
  }

  static Future<Database> initDB() async {
    final path = join(await getDatabasesPath(), 'app.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE,
            password TEXT
          )
        ''');

        await db.execute('''
          CREATE TABLE tasks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            isDone INTEGER,
            userId INTEGER
          )
        ''');
      },
    );
  }

  // ---------- AUTH ----------
  static Future<int> register(User user) async {
    final database = await db;
    return database.insert(
      'users',
      user.toMap(),
      conflictAlgorithm: ConflictAlgorithm.fail,
    );
  }

  static Future<User?> login(String email, String password) async {
    final database = await db;
    final res = await database.query(
      'users',
      where: 'email=? AND password=?',
      whereArgs: [email, password],
    );

    if (res.isNotEmpty) {
      return User.fromMap(res.first);
    }
    return null;
  }

  // ---------- TASKS ----------
  static Future<List<Task>> getTasks(int userId) async {
    final database = await db;
    final res = await database.query(
      'tasks',
      where: 'userId=?',
      whereArgs: [userId],
    );
    return res.map((e) => Task.fromMap(e)).toList();
  }

  static Future<int> insertTask(Task task) async {
    final database = await db;
    return database.insert('tasks', task.toMap());
  }

  static Future<int> updateTask(Task task) async {
    final database = await db;
    return database.update(
      'tasks',
      task.toMap(),
      where: 'id=?',
      whereArgs: [task.id],
    );
  }

  static Future<int> deleteTask(int id) async {
    final database = await db;
    return database.delete('tasks', where: 'id=?', whereArgs: [id]);
  }
}
